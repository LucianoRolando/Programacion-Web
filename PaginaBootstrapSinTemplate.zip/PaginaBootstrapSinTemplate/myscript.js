

function validacion() {
   
    var nom =document.getElementById("inputNom").value;
    var mail =document.getElementById("inputEml").value;
    var mnje =document.getElementById("inputMje").value;
   var no;
   var ma="";
   var me="";
   if(nom==""){
       no="\n -nombre";}
    else {
    no="";}
    if(mail==""){
        ma="\n -mail";}
     else {
     ma="";}
     if(mnje==""){
        me="\n -mensaje";}
     else {
     me="";}

    if (nom==""||mail==""||mnje=="") {
    alert("Falta completar: "+no+ma+me);
    }
    
    else {
    alert("Gracias por contactar");
    document.getElementById("inputNom").value="";
    document.getElementById("inputEml").value="";
    document.getElementById("inputMje").value="";
    }
    }
